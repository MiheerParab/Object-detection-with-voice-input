# object-detection-with-voice-feedback
This project detects 80 types of objects with the help of YOLO pre trained model and uses ffmpeg and gTTS to give the voice feedback. This project works in Real time with the help of webcam or any external camera.

# yolo
YOLO v3 Object Detection with Voice Feedback using gTTS


Download the yolov3 weights from
https://pjreddie.com/media/files/yolov3.weights
